# Rapport de Conception : Mise en œuvre des Design Patterns

**Projet :** SAE Groupe4_04  
**Binôme :** Oriane DELGADO, Ryan SEMAOUNE, Clara RENARD, Nhael GUILLARD  
**Date :** Janvier 2026

---

### Introduction

Dans le cadre du développement de notre plateforme de vente en ligne "E-Pokécard", nous avons identifié plusieurs problématiques de conception nécessitant une structuration robuste du code pour garantir son évolutivité et sa maintenabilité.

Au-delà de l'architecture MVC fournie par le framework CodeIgniter 4, nous avons implémenté manuellement plusieurs patrons de conception (*Design Patterns*) pour répondre à des besoins métier précis :

1. **Builder** (Création) : Pour la construction complexe des utilisateurs.
2. **Factory & Strategy** (Création & Comportement) : Pour l'instanciation dynamique et la gestion modulaire des paiements.
3. **Chain of Responsibility** (Comportement - *Pattern Original*) : Pour la validation séquentielle des commandes.
4. **Decorator** (Structure) : Pour la gestion dynamique des prix et affichages produits.



## 1. Patron de Conception : Builder (Monteur)

***Pattern Original (Non détaillé en cours)***

### 1.1 Justification du choix (Le Pourquoi ?)

Lors de la phase d'inscription, la création d'un utilisateur est un processus qui nécessite de collecter et de transformer plusieurs types de données : des identifiants de connexion, des informations d'identité civile et des attributions de droits (rôles).

Utiliser un constructeur classique ou un simple tableau associatif (`$data`) rendrait le code du contrôleur rigide et difficile à maintenir. Le choix du **Builder** s'est imposé pour :

* **Découpler** la logique de validation et de hachage de la logique de stockage.
* **Clarifier** l'intention du développeur grâce à une syntaxe explicite.
* **Sécuriser** la création en s'assurant que chaque étape (Credentials, Identity) est bien définie avant l'appel final.

### 1.2 Réponse au problème et Comparaison

Le DP Builder répond au problème de la construction d'objets complexes par étapes. Il permet de masquer les détails techniques (comme le hachage du mot de passe) derrière des méthodes compréhensibles.

| Solution | Avantages | Inconvénients |
| --- | --- | --- |
| **Constructeur direct** | Très simple pour de petits objets. | "Constructeur télescopique" illisible dès que l'objet dépasse 3 ou 4 paramètres. |
| **Setters classiques** | Flexible. | L'objet peut exister dans un état "incomplet" ou invalide entre deux appels de setters. |
| **Builder (Choisi)** | **Construction pas à pas** ; garantit l'intégrité de l'objet final ; code auto-documenté. | Légère verbosité supplémentaire dans le code du modèle. |

### 1.3 Conception (UML)

Dans cette architecture, nous avons adapté le pattern classique pour le rendre **"Fluent"** (interface fluide). Le contrôleur ne connaît pas la structure de la table SQL, il connaît seulement les "briques" de construction.

![Image du builder pattern](img/builder.png)

Ce diagramme montre comment le `UsersModel` absorbe le rôle du Builder pour simplifier l'accès aux données.

### 1.4 Implémentation (Le Comment ?)

L'implémentation repose sur le chaînage de méthodes. Chaque méthode de configuration enrichit un attribut temporaire (`$tempData`) et retourne l'instance elle-même (`$this`).

**Dans le Modèle (`UsersModel`) :**

```php
public function withCredentials(string $login, string $password): self 
{
    $this->tempData['login'] = $login;
    // Encapsulation d'une règle métier : le hachage automatique
    $this->tempData['password'] = password_hash($password, PASSWORD_DEFAULT);
    return $this; 
}

```

**Dans le Contrôleur (Inscription) :**
Le contrôleur agit comme le **Directeur** du pattern, il définit l'ordre d'assemblage :

```php
$success = $userModel->newUser()
    ->withCredentials($this->request->getPost('login'), $password)
    ->withIdentity($nom, $prenom, $email)
    ->withRole('client')
    ->create(); // Déclenche la sauvegarde finale

```

## 2. Patrons de Conception : Factory & Strategy (Paiement)

*Patterns vus en cours (Factory de Création + Strategy Comportemental).*

### 2.1 Justification du choix (Le Pourquoi ?)

Pour la gestion des paiements, nous avons combiné deux patrons de conception complémentaires :

**1. Factory (Création) :**
Le design pattern Factory est un patron de conception de création qui définit une interface pour créer des objets dans une classe mère, mais délègue le choix des types d’objets à créer aux sous-classes.

Nous avons choisi ce design pattern pour la gestion des préférences de paiement des utilisateurs du site. En effet, à chaque fois qu’un utilisateur passe à l’étape du paiement, il sélectionne l’option qu’il préfère (par carte bancaire ou paypal) via un formulaire. Cela crée un objet lié à l’utilisateur avec le choix de paiement sélectionné.

L’utilisation de ce design facilite la gestion des paiements et la maintenance du code, et permet d’ajouter d’autres moyens de paiements sans avoir à faire de modification majeure.

**2. Strategy (Comportemental) :**
Le design pattern Strategy est un patron de conception comportemental qui permet de définir une famille d’algorithmes, de les mettre dans des classes séparées et de rendre leurs objets interchangeables.

Nous avons choisi d’utiliser ce design pattern pour gérer les différents comportements liés aux moyens de paiement proposés à l’utilisateur. Chaque moyen de paiement possède un algorithme de traitement spécifique (validation d’une carte bancaire, redirection vers PayPal, etc.). Le patron Strategy permet de sélectionner dynamiquement l’algorithme approprié en fonction du choix fait par l’utilisateur, sans dupliquer le code. Il est complémentaire au design pattern Factory défini précédemment. 


**Comparaison avec le pattern Template Method :**

Nous avons décidé de ne pas utiliser le patron de conception comportemental Template. En effet, le patron Template définit un squelette d’algorithme dans la classe mère et laisse les sous-classes le redéfinir. Ici, nous avons préféré utiliser Strategy puisque les processus de paiement sont différents entre eux. Template proposant un squelette algorithmique commun, il n’était pas pertinent de l’utiliser contrairement à Strategy où l’algorithme change en fonction de la sous-classe choisie.

### 2.2 Illustrer et expliquer le DP choisi (Le Quoi ?)

![Image Strategy+Factory](img/factory+strategy.png)


Les deux patterns fonctionnent de manière complémentaire :

1. **Factory** (`PaymentFactory`) : Elle centralise la création. Sa méthode `create()` retourne une instance de stratégie.
2. **Strategy** (`PaymentStrategyInterface`) : Elle définit le contrat commun (méthode `pay()`).
3. **Concrétions** : Les classes `CreditCardPayment` et `PayPalPayment` implémentent la logique réelle.
4. **Base Commune** : Une classe abstraite `BasePaymentStrategy` fournit l'accès à la base de données pour éviter la duplication de code (DRY).

### 2.3 Présentation de l'implémentation (Le Comment ?)

L'implémentation se découpe en trois parties : l'interface, la logique de création (Factory) et l'exécution (Controller).

**1. L'Interface et la Base (Strategy)**

```php
// Contrat commun
interface PaymentStrategyInterface {  
    public function pay(int $commandeId): void; 
}

// Classe de base (Abstraite) pour l'accès BDD commun
abstract class BasePaymentStrategy implements PaymentStrategyInterface {  
    protected $db;

    public function __construct() { 
        $this->db = \Config\Database::connect(); 
    }

    // Méthode utilitaire partagée par toutes les stratégies
    protected function completeOrder(int $commandeId, string $label): void {  
        $this->db->table('commandes') 
            ->where('id', $commandeId)
            ->update([  
                'type_paiement' => $label, 
                'statut'        => 'validee' 
            ]); 
    }
}

```

**2. Les Stratégies Concrètes**

```php
class CreditCardPayment extends BasePaymentStrategy { 
    public function pay(int $commandeId): void {  
        // Logique spécifique CB
        $this->completeOrder($commandeId, 'Credit Card'); 
    } 
}

class PayPalPayment extends BasePaymentStrategy { 
    public function pay(int $commandeId): void { 
        // Logique spécifique PayPal
        $this->completeOrder($commandeId, 'Paypal');  
    }  
}

```

**3. La Factory (Le Créateur)**

```php
class PaymentFactory { 
    public static function create(string $type): PaymentStrategyInterface {  
        return match(strtolower($type)) {  
            'card'   => new CreditCardPayment(),
            'paypal' => new PayPalPayment(), 
            default  => throw new \Exception("Mode de paiement inconnu"), 
        };
    } 
}

```

**4. Utilisation dans le Contrôleur**

Le contrôleur ne connaît pas les classes `CreditCardPayment` ou `PayPalPayment`. Il demande juste une stratégie à la Factory et l'exécute.

```php
try {
    // 1. La Factory crée la bonne stratégie selon le choix utilisateur
    $strategy = PaymentFactory::create($typePaiement);
    
    // 2. On exécute le paiement (Strategy)
    $strategy->pay((int)$commandeId);

    return redirect()->to('/commande/confirmation/' . $commandeId)
                     ->with('success', 'PAIEMENT REÇU !');

} catch (\Exception $e) {
    return redirect()->back()->with('error', $e->getMessage());
}

```


## 3. Patron de Conception : Chain of Responsibility

***Pattern Original (Non détaillé en cours)***

### 3.1 Justification et Problématique

Avant de procéder au paiement effectif d'une commande, nous devons effectuer une **séquence de validations strictes** :

1. L'utilisateur est-il bien connecté ?
2. Le panier contient-il des articles (montant > 0) ?
3. Les produits sont-ils toujours en stock (vérification de dernière minute) ?
4. L'adresse de livraison est-elle valide ?

**Problème :** Coder ces vérifications successives dans le contrôleur mène à un "Spaghetti Code" de `if` imbriqués difficile à lire et à tester. De plus, l'ordre des vérifications est important.

**Solution :** La **Chain of Responsibility** permet de passer la demande (la commande à valider) le long d'une chaîne de "Handlers" (gestionnaires). Chaque maillon décide soit de traiter la demande et de la passer au suivant, soit d'arrêter la chaîne (en levant une exception par exemple) si la validation échoue.

**Avantage :** Ce pattern permet d'ajouter ou de retirer des étapes de validation (ex: ajout d'un filtre anti-fraude) sans modifier le code des autres vérifications.

### 3.2 Conception (UML)

![Image Chain](img/chain_of_responsibilty_commande.png)

Une classe abstraite `GestionVerificationCommande` définit la méthode `setNext()` et `handle()`. Des classes concrètes (`StockHandler`, `SoldeHandler`, `AuthHandler`) héritent de cette classe pour implémenter leur logique spécifique.

### 3.3 Implémentation

```php
// Handler Abstrait
abstract class GestionVerificationCommande {
    protected ?GestionVerificationCommande $nextHandler = null;

    public function setNext(GestionVerificationCommande $handler): GestionVerificationCommande {
        $this->nextHandler = $handler;
        return $handler; // Permet le chaînage fluide
    }

    public function handle($commande) {
        if ($this->nextHandler) {
            return $this->nextHandler->handle($commande);
        }
        return true; // Fin de chaîne, validation réussie
    }
}

// Maillon 1 : Vérification du montant
class SoldeVerif extends GestionVerificationCommande {
    public function handle($commande) {
        if ($commande->total <= 0) {
            throw new Exception("Erreur : Le montant de la commande est invalide.");
        }
        return parent::handle($commande);
    }
}

// Maillon 2 : Vérification du stock
class StockVerif extends GestionVerificationCommande {
    public function handle($commande) {
        foreach ($commande->getItems() as $item) {
            if (!$item->hasStock()) {
                throw new Exception("Rupture de stock pour : " . $item->getName());
            }
        }
        return parent::handle($commande);
    }
}

// Utilisation dans le Contrôleur de validation
try {
    // Construction de la chaîne
    $validationChain = new SoldeVerif();
    $validationChain
        ->setNext(new StockVerif())

    // Exécution
    $validationChain->handle($maCommande);
    
} catch (Exception $e) {
    return redirect()->back()->with('error', $e->getMessage());
}

```



## 4. Patron de Conception : Decorator (Décorateur)

***Pattern Original (Non détaillé en cours)***

#### 4.1 Justification et Problématique

Sur notre boutique, certains produits peuvent bénéficier d'une **Promotion** (réduction temporaire du prix).

**Problème :**
Actuellement, la logique de calcul du prix promotionnel est dispersée dans les vues (ex: `card_product.php`). Cela viole le principe de séparation des responsabilités. Si nous voulons changer la règle de calcul (ex: arrondir les prix promo), nous devons modifier toutes les vues. De plus, nous ne souhaitons pas modifier l'Entité `Produit` originale qui doit refléter strictement les données de la base.

**Solution :**
Le pattern **Decorator** permet d'envelopper l'entité `Produit` dans une classe `PromoDecorator`. Ce décorateur intercepte les appels pour obtenir le prix et applique la logique de réduction à la volée, sans toucher à la classe `Produit` ni à la base de données.

#### 4.2 Conception (UML)

![Image Decorator](img/decorator_pattern.png)

* **Composant (Interface/Abstrait)** : `ProductInterface` définit le contrat (méthodes `getPrix()` et `getHtmlBadge()`).
* **Composant Concret** : L'entité `Produit` de CodeIgniter.
* **Décorateur** : `PromoDecorator` qui contient une instance de `ProductInterface` et modifie le retour de `getPrix()`.

#### 4.3 Implémentation

Nous adaptons le pattern pour qu'il fonctionne avec les Entités de CodeIgniter.

**1. L'Interface (Contrat)**  
Pour uniformiser l'accès au prix, que ce soit un produit brut ou décoré.

```php
namespace App\Libraries\Patterns\Decorator;

interface ProductDisplayInterface {
    public function getPrix(): float;
    public function getBadgeHtml(): string;
    // Permet d'accéder aux autres propriétés (nom, image...) transparentement
    public function __get($name); 
}

```

**2. Le Décorateur Concret (Promotion)**  
Ce décorateur prend un produit (ou une entité) et applique la réduction si un taux est défini.

```php
namespace App\Libraries\Patterns\Decorator;

class PromoDecorator implements ProductDisplayInterface {
    protected $produit; // L'entité originale

    public function __construct($produit) {
        $this->produit = $produit;
    }

    public function getPrix(): float {
        // Logique métier centralisée : Calcul du prix réduit
        if (!empty($this->produit->tauxPromo)) {
             return $this->produit->prix * (1 - $this->produit->tauxPromo);
        }
        return $this->produit->prix;
    }

    public function getBadgeHtml(): string {
        if (!empty($this->produit->tauxPromo)) {
            $pourcentage = intval($this->produit->tauxPromo * 100);
            return "<div class='badge-promo'>-{$pourcentage}%</div>";
        }
        return "";
    }

    // Méthode magique pour déléguer tout le reste à l'entité originale
    // Ex: $decorator->nom renverra $produit->nom
    public function __get($name) {
        return $this->produit->$name;
    }
}

```

**3. Utilisation dans le Contrôleur (`Home.php`)**    
 Au lieu d'envoyer les entités brutes à la vue, nous les décorons.

```php

// ... Récupération des données ...
$promotionsBrutes = $promoBuilder->limit(3)->get()->getResult();

$promotionsDecorees = [];
foreach ($promotionsBrutes as $prod) {
    // On "emballe" le produit pour lui ajouter le comportement promo
    $promotionsDecorees[] = new \App\Libraries\Patterns\Decorator\PromoDecorator($prod);
}

// On envoie les objets décorés à la vue
$data['promotions'] = $promotionsDecorees;

```


**4. Simplification de la Vue (`card_product.php`)**  
La vue n'a plus besoin de faire de calculs (`$prix * taux`). Elle utilise simplement les méthodes de l'objet, qu'il soit décoré ou non.

```php
<div class="carte">
    <?= $produit->getBadgeHtml() ?> 

    <div class="carte-img-container">
        <img src="<?= base_url('assets/produits/' . esc($produit->image_url)) ?>" ...>
    </div>

    <div class="prix-container">
        <span class="prix-final">$<?= number_format($produit->getPrix(), 2) ?></span>
        
        <?php if(isset($produit->tauxPromo) && $produit->tauxPromo > 0): ?>
             <span class="prix-sup">$<?= esc($produit->prix) ?></span>
        <?php endif; ?>
    </div>
</div>

```



### Conclusion

L'implémentation de ces patterns nous a permis de découpler la logique métier de nos contrôleurs CodeIgniter :

* **Builder** sécurise la création des utilisateurs.
* **Factory & Strategy** centralisent la création des méthodes de paiement et rendent leur exécution interchangeable.
* **Chain of Responsibility** transforme la validation complexe en une chaîne de vérification flexible.
* **Decorator** gère la complexité des variantes de produits sans multiplier les classes.

Cette architecture garantit que l'ajout de nouvelles fonctionnalités aura un impact minimal sur le code existant.

