
# Patrons de Conception : Factory (Création) et Strategy (Comportemental)

## 1. Justification du choix (Le Pourquoi ?)

### Factory 


Le design pattern Factory est un patron de conception de création qui définit une interface pour créer des objets dans une classe mère, mais délègue le choix des types d’objets à créer aux sous-classes.

Nous avons choisi ce design pattern pour la gestion des préférences de paiement des utilisateurs du site. En effet, à chaque fois qu’un utilisateur passe à l’étape du paiement, il sélectionne l’option qu’il préfère (par carte bancaire ou paypal) via un formulaire. Cela crée un objet lié à l’utilisateur avec le choix de paiement sélectionné.

L’utilisation de ce design facilite la gestion des paiements et la maintenance du code, et permet d’ajouter d’autres moyens de paiements sans avoir à faire de modification majeure.

### Strategy

Le design pattern Strategy est un patron de conception comportemental qui permet de définir une famille d’algorithmes, de les mettre dans des classes séparées et de rendre leurs objets interchangeables.

Nous avons choisi d’utiliser ce design pattern pour gérer les différents comportements liés aux moyens de paiement proposés à l’utilisateur. Chaque moyen de paiement possède un algorithme de traitement spécifique (validation d’une carte bancaire, redirection vers PayPal, etc.). Le patron Strategy permet de sélectionner dynamiquement l’algorithme approprié en fonction du choix fait par l’utilisateur, sans dupliquer le code. Il est complémentaire au design pattern Factory défini précédemment. 

Nous avons décidé de ne pas utiliser le patron de conception comportemental Template. En effet, le patron Template définit un squelette d’algorithme dans la classe mère et laisse les sous-classes le redéfinir. Ici, nous avons préféré utiliser Strategy puisque les processus de paiement sont différents entre eux. Template proposant un squelette algorithmique commun, il n’était pas pertinent de l’utiliser contrairement à Strategy où l’algorithme change en fonction de la sous-classe choisie.

## 2. Illustrer et expliquer le DP choisi (Le Quoi ?)


![Image Strategy+Factory](img/factory+strategy.png)

Les design patterns Factory et Strategy sont utilisés de manière complémentaire afin de gérer les différents moyens de paiements possible pour l’utilisateur.  

Ici, le design pattern Factory crée des objets de paiement propre à chaque utilisateur, et le design pattern Strategy va permettre de définir et d’exécuter dynamiquement le mode de paiement choisi.

Dans ce diagramme UML, le design pattern Strategy est représenté via l’interface PaymentStrategyInterface qui va définir la méthode pay() qui sera commune aux différents types de paiements.  

La classe abstraite BasePaymentStrategy va fournir une implémentation commune partielle aux différentes stratégies.  

Les classes CreditCardPayment et PaypalPayment définissent chacune un moyen de paiement et vont implémenter la méthode pay() de manière spécifique en fonction du moyen de paiement représenté.  

Le design pattern Factory est utilisé pour centraliser la création des objets de type PaymentStrategyInterface.  
Il est représenté par la classe PaymentFactory qui va implémenter la méthode create() qui retournera une instance de stratégie en fonction du type de paiement choisi.

## 3. Présenter son implémentation (Le Comment ?)

### Factory

```php
class PaymentFactory { 
    public static function create(string $type): PaymentStrategyInterface {  
        return match(strtolower($type)) {  
            'card'   => new CreditCardPayment(),
            'paypal' => new PayPalPayment(), 
            default  => throw new \Exception("Mode inconnu"), 
        };
    } 
}
```


Ce code va créer des instances en fonction du design pattern Strategy.

```php
 try {
            $strategy = PaymentFactory::create($typePaiement);
            $strategy->pay((int)$commandeId);

            return redirect()->to('/commande/confirmation/' . $commandeId)
                ->with('success', 'PAIEMENT REÇU !');

        }

```

on crée la factory selon le type de paiement qu'on choisi alors
cela determine la stratégie de paiement


### Strategy 

```php
interface PaymentStrategyInterface {  
    public function pay(int $commandeId): void; 
}
```
Ce code va permettre de représenter l’algorithme de traitement du paiement qui sera adapté en fonction de la stratégie choisie. Cette interface va garantir l’interchangeabilité des stratégies.

```php
abstract class BasePaymentStrategy implements PaymentStrategyInterface {  
    protected $db;

   	public function __construct() { 
        $this->db = Config\Database::connect(); 
    }

    protected function completeOrder(int $commandeId, string $label): void {  
        $this->db->table('commandes') 
            ->where('id', $commandeId)
            ->update([  
                'type_paiement' => $label, 
                'statut'        => 'validee' 
            ]); 
    }
}
```
Cette classe va permettre l’accès à la base de données et va donner une implémentation partielle à appliquer en fonction des stratégies. La classe abstraite va éviter la duplication de code.

```php
class CreditCardPayment extends BasePaymentStrategy { 
    public function pay(int $commandeId): void {  
        $this->completeOrder($commandeId, 'Credit Card'); 
    } 
}

class PayPalPayment extends BasePaymentStrategy { 
    public function pay(int $commandeId): void { 
        $this->completeOrder($commandeId, 'Paypal');  
    }  
}
```
Ces classes définissent les différentes stratégies que l’utilisateur peut choisir.

