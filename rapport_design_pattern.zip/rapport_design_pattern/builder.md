# Patron de Conception : Builder (Monteur)

## 1. Justification du choix (Le Pourquoi ?)
Lors de la phase d'inscription, la création d'un utilisateur est un processus qui nécessite de collecter et de transformer plusieurs types de données : des identifiants de connexion, des informations d'identité civile et des attributions de droits (rôles).

Utiliser un constructeur classique ou un simple tableau associatif (`$data`) rendrait le code du contrôleur rigide et difficile à maintenir. Le choix du **Builder** s'est imposé pour :
* **Découpler** la logique de validation et de hachage de la logique de stockage.
* **Clarifier** l'intention du développeur grâce à une syntaxe explicite.
* **Sécuriser** la création en s'assurant que chaque étape (Credentials, Identity) est bien définie avant l'appel final.

---

## 2. Réponse au problème et Comparaison
Le DP Builder répond au problème de la construction d'objets complexes par étapes. Il permet de masquer les détails techniques (comme le hachage du mot de passe) derrière des méthodes compréhensibles.

| Solution | Avantages | Inconvénients |
| :--- | :--- | :--- |
| **Constructeur direct** | Très simple pour de petits objets. | "Constructeur télescopique" illisible dès que l'objet dépasse 3 ou 4 paramètres. |
| **Setters classiques** | Flexible. | L'objet peut exister dans un état "incomplet" ou invalide entre deux appels de setters. |
| **Builder (Choisi)** | **Construction pas à pas** ; garantit l'intégrité de l'objet final ; code auto-documenté. | Légère verbosité supplémentaire dans le code du modèle. |

---

## 3. Illustrer et expliquer le DP choisi (Le Quoi ?)
Dans cette architecture, nous avons adapté le pattern classique pour le rendre **"Fluent"** (interface fluide). Le contrôleur ne connaît pas la structure de la table SQL, il connaît seulement les "briques" de construction.

### Diagramme de Classe UML (Conception détaillée)
Ce diagramme montre comment le `UsersModel` absorbe le rôle du Builder pour simplifier l'accès aux données.




![Image du builder pattern](img/builder.png)
## 4. Présenter son implémentation (Le Comment ?)

### Extraits de code pertinents
L'implémentation repose sur le chaînage de méthodes. Chaque méthode de configuration enrichit un attribut temporaire (`$tempData`) et retourne l'instance elle-même (`$this`).

**Dans le Modèle (UsersModel) :**

```php
public function withCredentials(string $login, string $password): self 
{
    $this->tempData['login'] = $login;
    // Encapsulation d'une règle métier : le hachage automatique
    $this->tempData['password'] = password_hash($password, PASSWORD_DEFAULT);
    return $this; 
}
```

**Dans le Contrôleur (Inscription) :**
Le contrôleur agit comme le **Directeur** du pattern, il définit l'ordre d'assemblage :

```php
$success = $userModel->newUser()
    ->withCredentials($this->request->getPost('login'), $password)
    ->withIdentity($nom, $prenom, $email)
    ->withRole('client')
    ->create(); // Déclenche la sauvegarde finale
```